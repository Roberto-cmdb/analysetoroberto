package com.example.techanalysis

import com.example.techanalysis.domain.Alerts
import org.junit.Assert.assertEquals
import org.junit.Test

class AlertsTest {
    @Test fun horizontalIsConstant() =
        assertEquals(100.0, Alerts.linePrice("H", 0, 100.0, 0, 100.0, 5_000), 1e-9)

    @Test fun trendIsExtrapolated() =
        assertEquals(130.0, Alerts.linePrice("T", 0, 100.0, 100, 110.0, 300), 1e-9)

    @Test fun sides() {
        assertEquals(1, Alerts.side(101.0, 100.0))
        assertEquals(-1, Alerts.side(99.0, 100.0))
        assertEquals(0, Alerts.side(100.0, 100.0))
    }
}
