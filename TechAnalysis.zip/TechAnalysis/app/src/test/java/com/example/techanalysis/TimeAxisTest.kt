package com.example.techanalysis

import com.example.techanalysis.domain.Candle
import com.example.techanalysis.domain.TimeAxis
import org.junit.Assert.assertEquals
import org.junit.Test

class TimeAxisTest {
    private val c = (0 until 10).map { Candle(1000L + it * 60L, 1.0, 1.0, 1.0, 1.0) }

    @Test fun roundTripInside() {
        assertEquals(3.5, TimeAxis.indexAt(c, TimeAxis.timeAt(c, 3.5)), 1e-6)
    }
    @Test fun extrapolatesIntoFuture() {
        assertEquals(12.0, TimeAxis.indexAt(c, TimeAxis.timeAt(c, 12.0)), 1e-6)
    }
}
