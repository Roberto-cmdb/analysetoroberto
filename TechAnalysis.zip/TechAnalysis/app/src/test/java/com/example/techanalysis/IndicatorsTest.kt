package com.example.techanalysis

import com.example.techanalysis.domain.Indicators
import org.junit.Assert.*
import org.junit.Test

class IndicatorsTest {
    @Test fun smaBasic() {
        val r = Indicators.sma(listOf(1.0, 2.0, 3.0, 4.0), 2)
        assertNull(r[0]); assertEquals(1.5, r[1]!!, 1e-9); assertEquals(3.5, r[3]!!, 1e-9)
    }
    @Test fun rsiAllGainsIs100() {
        val r = Indicators.rsi((1..30).map { it.toDouble() }, 14)
        assertEquals(100.0, r.last()!!, 1e-9)
    }
    @Test fun rsiWilderReference() {
        // Série de référence de Wilder / StockCharts : RSI(14) ≈ 70.5 au 15e point
        val c = listOf(44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28)
        assertEquals(70.5, Indicators.rsi(c, 14).last()!!, 0.6)
    }
}
