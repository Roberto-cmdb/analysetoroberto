package com.example.techanalysis.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.techanalysis.domain.Candle
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "candles", primaryKeys = ["symbolKey", "timeframe", "time"])
data class CandleEntity(
    val symbolKey: String, val timeframe: String, val time: Long,
    val open: Double, val high: Double, val low: Double, val close: Double,
)

/** kind : "H" = ligne horizontale (support/résistance), "T" = ligne de tendance. */
@Entity(tableName = "drawings")
data class DrawingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbolKey: String, val timeframe: String, val kind: String,
    val t1: Long, val p1: Double, val t2: Long, val p2: Double,
    @ColumnInfo(defaultValue = "0") val alert: Boolean = false,
    /** Côté du prix par rapport à la ligne au dernier contrôle (-1, 0, +1). */
    @ColumnInfo(defaultValue = "0") val lastSide: Int = 0,
)

@Dao
interface AppDao {
    @Query("SELECT * FROM candles WHERE symbolKey = :key AND timeframe = :tf ORDER BY time DESC LIMIT :n")
    suspend fun lastCandles(key: String, tf: String, n: Int): List<CandleEntity>

    @Upsert suspend fun upsertCandles(list: List<CandleEntity>)

    @Query("SELECT * FROM drawings WHERE symbolKey = :key AND timeframe = :tf")
    fun observeDrawings(key: String, tf: String): Flow<List<DrawingEntity>>

    @Query("SELECT * FROM drawings WHERE alert = 1")
    fun observeAlerts(): Flow<List<DrawingEntity>>

    @Query("UPDATE drawings SET alert = :on, lastSide = 0 WHERE id = :id")
    suspend fun setAlert(id: Long, on: Boolean)

    @Query("UPDATE drawings SET lastSide = :side WHERE id = :id")
    suspend fun setSide(id: Long, side: Int)

    @Insert suspend fun insertDrawing(d: DrawingEntity)
    @Query("DELETE FROM drawings WHERE id = :id") suspend fun deleteDrawing(id: Long)
    @Query("DELETE FROM drawings WHERE symbolKey = :key AND timeframe = :tf") suspend fun clearDrawings(key: String, tf: String)
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE drawings ADD COLUMN alert INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE drawings ADD COLUMN lastSide INTEGER NOT NULL DEFAULT 0")
    }
}

@Database(entities = [CandleEntity::class, DrawingEntity::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "techanalysis.db").addMigrations(MIGRATION_1_2).build().also { inst = it }
        }
    }
}

fun CandleEntity.toCandle() = Candle(time, open, high, low, close)
fun Candle.toEntity(key: String, tf: String) = CandleEntity(key, tf, time, open, high, low, close)
