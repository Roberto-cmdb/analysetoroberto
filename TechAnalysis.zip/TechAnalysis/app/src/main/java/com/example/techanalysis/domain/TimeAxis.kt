package com.example.techanalysis.domain

/** Les tracés sont stockés en (temps, prix) : ils restent valables quand les bougies changent. */
object TimeAxis {
    fun indexAt(c: List<Candle>, time: Long): Double {
        val n = c.size
        if (n < 2) return 0.0
        if (time >= c[n - 1].time) return (n - 1) + (time - c[n - 1].time).toDouble() / (c[n - 1].time - c[n - 2].time)
        if (time <= c[0].time) return (time - c[0].time).toDouble() / (c[1].time - c[0].time)
        var lo = 0; var hi = n - 1
        while (hi - lo > 1) { val m = (lo + hi) / 2; if (c[m].time <= time) lo = m else hi = m }
        return lo + (time - c[lo].time).toDouble() / (c[hi].time - c[lo].time)
    }

    fun timeAt(c: List<Candle>, idx: Double): Long {
        val n = c.size
        if (n < 2) return 0L
        return when {
            idx >= n - 1 -> c[n - 1].time + ((idx - (n - 1)) * (c[n - 1].time - c[n - 2].time)).toLong()
            idx <= 0 -> c[0].time + (idx * (c[1].time - c[0].time)).toLong()
            else -> { val i = idx.toInt(); c[i].time + ((idx - i) * (c[i + 1].time - c[i].time)).toLong() }
        }
    }
}
