package com.example.techanalysis.domain

/** Règles d'alerte : une alerte se déclenche quand le prix passe de l'autre côté de la ligne. */
object Alerts {
    /** Prix de la ligne à l'instant [t] (horizontale : constant ; tendance : prolongée linéairement). */
    fun linePrice(kind: String, t1: Long, p1: Double, t2: Long, p2: Double, t: Long): Double =
        if (kind == "H" || t2 == t1) p1 else p1 + (p2 - p1) * (t - t1).toDouble() / (t2 - t1)

    /** +1 au-dessus de la ligne, -1 en dessous, 0 exactement dessus. */
    fun side(price: Double, line: Double): Int = when {
        price > line -> 1
        price < line -> -1
        else -> 0
    }
}
