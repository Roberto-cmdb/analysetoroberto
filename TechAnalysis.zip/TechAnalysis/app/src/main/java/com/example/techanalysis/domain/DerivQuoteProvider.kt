package com.example.techanalysis.domain

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Erreur renvoyée par l'API elle-même (symbole invalide, etc.). */
class DerivException(message: String) : Exception(message)

/**
 * Cotations publiques Deriv (aucun jeton requis).
 * Essaie d'abord le nouveau point d'accès public, puis les anciens, et retient celui qui répond.
 */
class DerivQuoteProvider(
    private val endpoints: List<String> = DEFAULT_ENDPOINTS,
    private val client: OkHttpClient = OkHttpClient(),
) : QuoteProvider {

    @Volatile private var working: String? = null

    private fun candidates(): List<String> = listOfNotNull(working) + endpoints.filter { it != working }

    private fun wsRequest(url: String) = Request.Builder().url(url).build()

    private fun granularity(tf: Timeframe) = when (tf) {
        Timeframe.M1 -> 60
        Timeframe.M5 -> 300
        Timeframe.M15 -> 900
        Timeframe.H1 -> 3600
        Timeframe.D1 -> 86400
    }

    private fun candlesBody(symbol: String, tf: Timeframe, count: Int, subscribe: Boolean) = JSONObject()
        .put("ticks_history", symbol)
        .put("adjust_start_time", 1)
        .put("count", count)
        .put("end", "latest")
        .put("style", "candles")
        .put("granularity", granularity(tf))
        .apply { if (subscribe) put("subscribe", 1) }
        .toString()

    private fun errorOf(j: JSONObject): String? = j.optJSONObject("error")?.optString("message")

    private suspend fun oneShotAt(url: String, request: String, key: String): JSONObject =
        withTimeoutOrNull(10_000) {
            suspendCancellableCoroutine<JSONObject> { cont ->
                val ws = client.newWebSocket(wsRequest(url), object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(request) }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        val j = JSONObject(text)
                        val err = errorOf(j)
                        if (err != null) {
                            if (cont.isActive) cont.resumeWithException(DerivException(err))
                            webSocket.close(1000, null)
                            return
                        }
                        if (!j.has(key)) return
                        if (cont.isActive) cont.resume(j)
                        webSocket.close(1000, null)
                    }

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                })
                cont.invokeOnCancellation { ws.cancel() }
            }
        } ?: throw IOException("aucune réponse de ${url.substringBefore('?')}")

    /** Envoie la requête sur chaque point d'accès jusqu'à obtenir une réponse. */
    private suspend fun oneShot(request: String, key: String): JSONObject {
        var last: Exception? = null
        for (url in candidates()) {
            try {
                val j = oneShotAt(url, request, key)
                working = url
                return j
            } catch (e: CancellationException) {
                throw e
            } catch (e: DerivException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw IOException("Connexion Deriv impossible : ${last?.message ?: "aucune réponse"}")
    }

    override suspend fun history(symbol: String, timeframe: Timeframe, count: Int): List<Candle> {
        val arr = oneShot(candlesBody(symbol, timeframe, count, false), "candles").getJSONArray("candles")
        return (0 until arr.length()).map { i ->
            val c = arr.getJSONObject(i)
            Candle(c.getLong("epoch"), c.getDouble("open"), c.getDouble("high"), c.getDouble("low"), c.getDouble("close"))
        }
    }

    override suspend fun symbols(): List<SymbolInfo> {
        val req = JSONObject().put("active_symbols", "brief").put("product_type", "basic").toString()
        val arr = oneShot(req, "active_symbols").getJSONArray("active_symbols")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val s = o.getString("symbol")
            SymbolInfo(s, o.optString("display_name", s), o.optString("market_display_name", o.optString("market", "Autres")))
        }.sortedBy { it.name }
    }

    override fun stream(symbol: String, timeframe: Timeframe): Flow<Candle> = callbackFlow {
        val url = working ?: endpoints.first()
        val ws = client.newWebSocket(wsRequest(url), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(candlesBody(symbol, timeframe, 1, subscribe = true))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val j = JSONObject(text)
                errorOf(j)?.let { close(DerivException(it)); return }
                j.optJSONObject("ohlc")?.let { o ->
                    trySend(Candle(o.getLong("open_time"), o.getDouble("open"), o.getDouble("high"), o.getDouble("low"), o.getDouble("close")))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { close(t) }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { close() }
        })
        awaitClose { ws.cancel() }
    }

    companion object {
        val DEFAULT_ENDPOINTS = listOf(
            "wss://api.derivws.com/trading/v1/options/ws/public",
            "wss://ws.derivws.com/websockets/v3?app_id=1089",
            "wss://ws.binaryws.com/websockets/v3?app_id=1089",
        )
    }
}
