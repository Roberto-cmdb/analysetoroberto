package com.example.techanalysis.ui

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.techanalysis.AlertService
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.techanalysis.data.*
import com.example.techanalysis.domain.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Layer(val label: String) { SMA("SMA 20"), EMA("EMA 50"), BOLL("Bollinger"), RSI("RSI"), MACD("MACD") }
enum class DataSource { DEMO, DERIV }

data class UiState(
    val symbol: String = "DEMO",
    val source: DataSource = DataSource.DEMO,
    val timeframe: Timeframe = Timeframe.D1,
    val analysis: Analysis = Analysis(emptyList()),
    val layers: Set<Layer> = Layer.entries.toSet() - Layer.BOLL,
    val symbols: List<SymbolInfo> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
)

class ChartViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val providers: Map<DataSource, QuoteProvider> = mapOf(
        DataSource.DEMO to SampleQuoteProvider(),
        DataSource.DERIV to DerivQuoteProvider(),
    )
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    private fun keyOf(s: UiState) = "${s.source.name}:${s.symbol}"

    @OptIn(ExperimentalCoroutinesApi::class)
    val drawings: StateFlow<List<DrawingEntity>> = _state
        .map { keyOf(it) to it.timeframe.name }
        .distinctUntilChanged()
        .flatMapLatest { (k, tf) -> dao.observeDrawings(k, tf) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init { load() }

    /** Charge le cache, puis l'historique en ligne, puis suit la bougie en cours. */
    fun load(
        symbol: String = _state.value.symbol,
        source: DataSource = _state.value.source,
        tf: Timeframe = _state.value.timeframe,
    ) {
        job?.cancel()
        val sym = symbol.trim().ifEmpty { "DEMO" }
        _state.update {
            it.copy(symbol = sym, source = source, timeframe = tf, analysis = Analysis(emptyList()), loading = true, error = null)
        }
        job = viewModelScope.launch {
            val p = providers.getValue(source)
            val key = keyOf(_state.value)
            val cacheable = source == DataSource.DERIV
            try {
                if (cacheable) {
                    val cached = dao.lastCandles(key, tf.name, 400).reversed().map { it.toCandle() }
                    if (cached.isNotEmpty()) _state.update { it.copy(analysis = Analysis(cached)) }
                }
                val history = try {
                    p.history(sym, tf, 400)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (_state.value.analysis.candles.isNotEmpty()) {
                        _state.update { it.copy(loading = false, error = "Hors ligne, données du cache (${e.message})") }
                        return@launch
                    }
                    throw e
                }
                if (cacheable) dao.upsertCandles(history.map { it.toEntity(key, tf.name) })
                _state.update { it.copy(analysis = Analysis(history), loading = false) }
                p.stream(sym, tf).collect { c ->
                    _state.update { s ->
                        val list = s.analysis.candles.toMutableList()
                        when {
                            list.isEmpty() || c.time > list.last().time -> list += c
                            c.time == list.last().time -> list[list.lastIndex] = c
                            else -> return@update s
                        }
                        s.copy(analysis = Analysis(list))
                    }
                    if (cacheable) dao.upsertCandles(listOf(c.toEntity(key, tf.name)))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Connexion impossible") }
            }
        }
    }

    fun loadSymbols() {
        if (_state.value.symbols.isNotEmpty()) return
        viewModelScope.launch {
            try {
                val list = providers.getValue(DataSource.DERIV).symbols()
                _state.update {
                    it.copy(symbols = list, error = if (list.isEmpty()) "Liste indisponible : saisissez le symbole à la main." else it.error)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = "Liste des symboles : ${e.message}") }
            }
        }
    }

    fun importCsv(name: String, text: String) {
        runCatching { Csv.parse(text) }
            .onSuccess { c ->
                job?.cancel()
                _state.update { it.copy(symbol = name, source = DataSource.DEMO, analysis = Analysis(c), loading = false, error = null) }
            }
            .onFailure { e -> _state.update { it.copy(error = e.message ?: "Fichier illisible") } }
    }

    fun toggle(layer: Layer) = _state.update {
        it.copy(layers = if (layer in it.layers) it.layers - layer else it.layers + layer)
    }

    // ---- tracés ----
    fun addDrawing(kind: String, t1: Long, p1: Double, t2: Long = t1, p2: Double = p1) = viewModelScope.launch {
        val s = _state.value
        dao.insertDrawing(DrawingEntity(symbolKey = keyOf(s), timeframe = s.timeframe.name, kind = kind, t1 = t1, p1 = p1, t2 = t2, p2 = p2))
    }

    /** Active ou coupe l'alerte d'une ligne ; démarre le service de surveillance si besoin. */
    fun toggleAlert(id: Long) {
        val d = drawings.value.firstOrNull { it.id == id } ?: return
        if (!d.symbolKey.startsWith("DERIV:")) {
            _state.update { it.copy(error = "Les alertes nécessitent la source Deriv.") }
            return
        }
        viewModelScope.launch {
            dao.setAlert(id, !d.alert)
            if (!d.alert) {
                val app = getApplication<Application>()
                ContextCompat.startForegroundService(app, Intent(app, AlertService::class.java))
            }
        }
    }

    fun deleteDrawing(id: Long) = viewModelScope.launch { dao.deleteDrawing(id) }

    fun clearDrawings() = viewModelScope.launch {
        val s = _state.value
        dao.clearDrawings(keyOf(s), s.timeframe.name)
    }
}
