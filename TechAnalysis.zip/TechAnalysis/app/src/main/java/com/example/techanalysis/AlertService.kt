package com.example.techanalysis

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import com.example.techanalysis.data.AppDao
import com.example.techanalysis.data.AppDb
import com.example.techanalysis.data.DrawingEntity
import com.example.techanalysis.domain.Alerts
import com.example.techanalysis.domain.DerivQuoteProvider
import com.example.techanalysis.domain.Timeframe
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Surveille en arrière-plan les lignes dont l'alerte est active (flux Deriv M1)
 * et notifie quand le prix les franchit. S'arrête seul quand plus aucune alerte n'est active.
 */
class AlertService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val provider = DerivQuoteProvider()
    private val streams = mutableMapOf<String, Job>()
    private val fired = ConcurrentHashMap.newKeySet<Long>()
    @Volatile private var alerts: List<DrawingEntity> = emptyList()
    private var watcher: Job? = null
    private lateinit var dao: AppDao

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        dao = AppDb.get(this).dao()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_WATCH, "Surveillance", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Alertes de prix", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ongoing = NotificationCompat.Builder(this, CH_WATCH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Alertes de prix actives")
            .setContentText("Surveillance de vos lignes en cours")
            .setOngoing(true)
            .setContentIntent(openApp())
            .build()
        ServiceCompat.startForeground(this, ONGOING_ID, ongoing, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (watcher == null) watcher = scope.launch { dao.observeAlerts().collect { sync(it) } }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun sync(list: List<DrawingEntity>) {
        val active = list.filter { it.symbolKey.startsWith("DERIV:") }
        alerts = active
        fired.retainAll(active.map { it.id }.toSet())
        val symbols = active.map { it.symbolKey.removePrefix("DERIV:") }.toSet()
        streams.keys.filter { it !in symbols }.forEach { streams.remove(it)?.cancel() }
        symbols.filter { it !in streams }.forEach { sym -> streams[sym] = scope.launch { watch(sym) } }
        if (symbols.isEmpty()) stopSelf()
    }

    /** Reste connecté au symbole ; se reconnecte après une coupure. */
    private suspend fun watch(sym: String) {
        while (true) {
            try {
                provider.stream(sym, Timeframe.M1).collect { check(sym, it.close) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
            delay(5_000)
        }
    }

    private suspend fun check(sym: String, price: Double) {
        val now = System.currentTimeMillis() / 1000
        for (d in alerts) {
            if (d.symbolKey != "DERIV:$sym" || d.id in fired) continue
            val side = Alerts.side(price, Alerts.linePrice(d.kind, d.t1, d.p1, d.t2, d.p2, now))
            when {
                d.lastSide == 0 -> if (side != 0) dao.setSide(d.id, side)
                side != 0 && side != d.lastSide -> {
                    fired.add(d.id)
                    notifyCross(sym, d, price)
                    dao.setAlert(d.id, false) // alerte à usage unique
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun notifyCross(sym: String, d: DrawingEntity, price: Double) {
        val what = if (d.kind == "H") "votre niveau" else "votre ligne de tendance"
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Alerte $sym")
            .setContentText("Le prix a franchi $what (${"%.2f".format(price)})")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        val nm = NotificationManagerCompat.from(this)
        if (nm.areNotificationsEnabled()) nm.notify(1000 + d.id.toInt(), n)
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
    )

    private companion object {
        const val CH_WATCH = "watch"
        const val CH_ALERT = "alerts"
        const val ONGOING_ID = 1
    }
}
