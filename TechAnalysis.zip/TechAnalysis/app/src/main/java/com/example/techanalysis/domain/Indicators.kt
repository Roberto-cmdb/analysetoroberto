package com.example.techanalysis.domain

import kotlin.math.sqrt

/** Indicateurs en Kotlin pur : aucune dépendance Android, donc testables sur la JVM. */
object Indicators {

    fun sma(v: List<Double>, n: Int): List<Double?> {
        val out = MutableList<Double?>(v.size) { null }
        var sum = 0.0
        for (i in v.indices) {
            sum += v[i]
            if (i >= n) sum -= v[i - n]
            if (i >= n - 1) out[i] = sum / n
        }
        return out
    }

    /** EMA sur une série pouvant commencer par des null. Amorcée avec la SMA des n premières valeurs. */
    fun ema(v: List<Double?>, n: Int): List<Double?> {
        val out = MutableList<Double?>(v.size) { null }
        val start = v.indexOfFirst { it != null }
        if (start < 0 || start + n > v.size) return out
        val seed = start + n - 1
        var prev = (start..seed).sumOf { v[it]!! } / n
        out[seed] = prev
        val k = 2.0 / (n + 1)
        for (i in seed + 1 until v.size) {
            prev = v[i]!! * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    /** RSI de Wilder. */
    fun rsi(close: List<Double>, n: Int = 14): List<Double?> {
        val out = MutableList<Double?>(close.size) { null }
        if (close.size <= n) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..n) {
            val d = close[i] - close[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        gain /= n; loss /= n
        fun value() = if (loss == 0.0) 100.0 else 100 - 100 / (1 + gain / loss)
        out[n] = value()
        for (i in n + 1 until close.size) {
            val d = close[i] - close[i - 1]
            gain = (gain * (n - 1) + maxOf(d, 0.0)) / n
            loss = (loss * (n - 1) + maxOf(-d, 0.0)) / n
            out[i] = value()
        }
        return out
    }

    data class Macd(val line: List<Double?>, val signal: List<Double?>, val hist: List<Double?>)

    fun macd(close: List<Double>, fast: Int = 12, slow: Int = 26, sig: Int = 9): Macd {
        val f = ema(close, fast)
        val s = ema(close, slow)
        val line = close.indices.map { i -> if (f[i] != null && s[i] != null) f[i]!! - s[i]!! else null }
        val signal = ema(line, sig)
        val hist = close.indices.map { i -> if (line[i] != null && signal[i] != null) line[i]!! - signal[i]!! else null }
        return Macd(line, signal, hist)
    }

    data class Bands(val upper: List<Double?>, val middle: List<Double?>, val lower: List<Double?>)

    fun bollinger(close: List<Double>, n: Int = 20, k: Double = 2.0): Bands {
        val mid = sma(close, n)
        val up = MutableList<Double?>(close.size) { null }
        val lo = MutableList<Double?>(close.size) { null }
        for (i in n - 1 until close.size) {
            val m = mid[i]!!
            var s = 0.0
            for (j in i - n + 1..i) s += (close[j] - m) * (close[j] - m)
            val sd = sqrt(s / n)
            up[i] = m + k * sd
            lo[i] = m - k * sd
        }
        return Bands(up, mid, lo)
    }
}

/** Tous les indicateurs calculés une fois pour une série de bougies. */
class Analysis(val candles: List<Candle>) {
    private val closes = candles.map { it.close }
    val sma20 = Indicators.sma(closes, 20)
    val ema50 = Indicators.ema(closes, 50)
    val bands = Indicators.bollinger(closes)
    val rsi = Indicators.rsi(closes)
    val macd = Indicators.macd(closes)
}
